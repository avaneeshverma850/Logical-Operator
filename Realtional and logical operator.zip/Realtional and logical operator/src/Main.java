import static java.lang.System.*;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        //Relational and Logical  operator in java
        // Relational Operator
        //==,>=,>,<,<=,!=
        //Logical Operator
        System.out.println("For logical And ,,,");
        boolean a = true;
        boolean b = true;
        boolean c = true;
        if (a && b && c) {
            System.out.println("Y");
        } else {
            System.out.println("N");
        }
        //Logical OR
        System.out.println("For logical Or ,,,");
        boolean a1 = false;
        boolean b1 = false;
        boolean c1 = false;
        if (a1 || b1 || c1) {
            System.out.println("Y");
        } else {
            System.out.println("N");
        }
        //Logical Not
        System.out.println("For logical NOT ,,,");
        boolean a2 = false;
        boolean b2 = false;
        boolean c2 = false;
        if (!a2) {
            System.out.println("Y");
        } else {
            System.out.println("N");

        }
    }
}